Submission to NIST’s post-quantum project (2nd round):
lattice-based digital signature scheme qTESLA
--------------------------------------------------------------------------------

Name of the cryptosystem: qTESLA
Principal and auxiliary submitters:
Sedat Akleylek, Erdem Alkim, Paulo Barreto, Nina Bindel, Johannes Buchmann, 
Edward Eaton, Gus Gutoski, Juliane Krämer, Patrick Longa, Harun Polat, 
Jefferson Ricardini, and Gustavo Zanon
--------------------------------------------------------------------------------

The submission of the lattice-based digital signature scheme qTESLA includes three 
folders:

- "KAT":                      Contains the Known Answer Tests
- "Reference_implementation": Contains the reference implementation
- "Additional_implementations\avx2": Contains the AVX2-optimized implementation
- "Supporting_Documentation": Contains electronic version of all written 
                              materials, our sage script to choose parameters, 
                              and the submitters statements  

We list all files in the subfolders and give a brief description of each.
--------------------------------------------------------------------------------
Subfolder "KAT":
This folder contains knowns answer tests results for the proposed parameter sets.

- "\ref\PQCsignKAT_qTesla-p-I.rsp"   : Known answer test results for qTesla-p-I, ref implementation
- "\ref\PQCsignKAT_qTesla-p-III.rsp" : Known answer test results for qTesla-p-III, ref implementation
- "\avx2\PQCsignKAT_qTesla-p-I.rsp"   : Known answer test results for qTesla-p-I, AVX2 implementation
- "\avx2\PQCsignKAT_qTesla-p-III.rsp" : Known answer test results for qTesla-p-III, AVX2 implementation

--------------------------------------------------------------------------------
Subfolder "Reference_implementation":
This folder contains the following subfolders which contain the reference implementations
for the proposed parameter sets:

- "qTesla-p-I" : Reference implementation of qTesla-p-I with parameters for
                 NIST’s security category 1
- "qTesla-p-III" : Reference implementation of qTesla-p-III with parameters for
                   NIST’s security category 3

--------------------------------------------------------------------------------
Subfolder "Additional_implementations\avx2":
This folder contains the following subfolders which contain the AVX2 implementations
for the proposed parameter sets:

- "qTesla-p-I" : AVX2 implementation of qTesla-p-I with parameters for
                 NIST’s security category 1
- "qTesla-p-III" : AVX2 implementation of qTesla-p-III with parameters for
                   NIST’s security category 3

--------------------------------------------------------------------------------
Subfolder "Supporting_Documentation":
This folder contains the following subfolders. 

- "Implementation_owners_statements_qTESLA": This folder contains the statements
according to Section 2.D.3 in NIST's call for proposals. Each file is named
"qTESLA-implementation-owners-statement-NAME.pdf" where NAME is the family
name of one of the implementations owners, i.e., Akleylek, Alkim, Barreto, Longa,
Polat, Ricardini, or Zanon. 

- "Submitters_statements_qTESLA": This folder contains the statements
according to Section 2.D.1 in NIST's call for proposals. Each file is named
"qTESLA-NIST-submitters-statement-NAME.pdf" where NAME is the family name of one
of the submitters, i.e., Akleylek, Alkim, Barreto, Bindel, Buchmann, Eaton, 
Gutoski, Krämer, Longa, Polat, Ricardini, or Zanon. 

- "Script_to_choose_parameters": This folder contains all files needed to run
the sage script that we used to choose our proposed parameter sets. Those files are: 

   - "README_Script_Parameterchoice.rst": This is the README file of our sage
                     script to compute parameters.
   - "parameterchoice.sage": This file is the main file to compute all system
                     parameters and estimate the hardness of the corresponding 
                     R-LWE and R-SIS instance. To this end it calls a function defined in
                     "estimator.py"
   - "README_LWE_Estimator.rst": This is the README file of the LWE-Estimator 
                     written by Albrecht, Player, and Scott. We use the 
                     LWE-Estimator to estimate the hardness of our chosen LWE 
                     instances.
   - "estimator.py": This python script is the implementation of the 
                     LWE-Estimator by Albrecht, Play, and Scott that we call in
                     our sage script "parameterchoice.sage".
   - The rest of the contained files are subroutines of the LWE-Estimator. We 
                     do not describe them in detail here but refer to the 
                     README file of the LWE-Estimator. 

- "Script_for_conjecture": This folder contains a README file and the corresponding script 
Script_for_experiments_supporting_the_security_conjecture.py to run experiments that support 
the conjecture used in the security reduction.

- "Script_for_Gaussian_sampler": This folder contains the script qCDT.sage to generate
the precomputed CDT tables required by the Gaussian sampler.

- "qTESLA_round2_14.04.2020.pdf": This pdf file is the description of our scheme qTESLA. We give 
all supporting information about our submitted signature scheme in the pdf.

- "qTESLA_modifications_round2_14.04.2020.pdf": This pdf file contains a summary of the modifications 
of qTESLA for the submission in the second round. 
