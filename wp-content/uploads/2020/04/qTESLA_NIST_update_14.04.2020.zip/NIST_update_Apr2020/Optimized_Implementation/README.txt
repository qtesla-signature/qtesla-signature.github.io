
For all the parameter sets, the reference implementation is 
the optimized implementation for this version of the software.